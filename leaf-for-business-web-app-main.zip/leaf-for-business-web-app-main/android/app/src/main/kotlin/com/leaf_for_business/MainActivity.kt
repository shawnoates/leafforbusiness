package com.leaf_for_business

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
