const inputs = require('../../js/inputs');

module.exports = [
  inputs.dataModelName,
]
