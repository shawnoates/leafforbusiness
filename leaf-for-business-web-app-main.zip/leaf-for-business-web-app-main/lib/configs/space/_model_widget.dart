part of '../configs.dart';

class _SpaceModelWidget {
  final Widget t05;
  final Widget t10;
  final Widget t15;
  final Widget t20;
  final Widget t25;
  final Widget t30;
  final Widget t60;
  final Widget t100;

  _SpaceModelWidget({
    required this.t05,
    required this.t10,
    required this.t15,
    required this.t20,
    required this.t25,
    required this.t30,
    required this.t60,
    required this.t100,
  });
}
