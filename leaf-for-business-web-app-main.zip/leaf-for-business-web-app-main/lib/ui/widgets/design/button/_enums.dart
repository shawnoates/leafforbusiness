part of 'button.dart';

enum AppButtonStyle {
  dark,
  green,
  white,
  danger,
}

enum AppButtonState {
  elevated,
  disabled,
  plain,
}
