part of '../search_business.dart';

class _FormKeys {
  static const searchBusiness = "searchBusiness";
  static const location = "location";
}
