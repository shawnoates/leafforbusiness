part of '../search_business.dart';

class _FormData {
  static Map<String, dynamic> initialValues() {
    return {};
  }
}
