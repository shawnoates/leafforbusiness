part of '../create_promotion.dart';

class _FormData {
  static Map<String, dynamic> initialValues() {
    return {};
  }
}
