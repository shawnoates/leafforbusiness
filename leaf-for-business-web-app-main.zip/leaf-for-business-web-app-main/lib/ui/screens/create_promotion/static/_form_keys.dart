part of '../create_promotion.dart';

class _FormKeys {
  static const name = "name";
  static const email = "email";
  static const startDate = "startDate";
  static const endDate = "endDate";
  static const headline = "headline";
  static const note = "note";
}
