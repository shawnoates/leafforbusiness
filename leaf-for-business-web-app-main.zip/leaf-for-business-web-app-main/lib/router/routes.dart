abstract class AppRoutes {
  static const orderConfirmation = '/order-confirmation';
  static const searchBussiness = '/search-business';
  static const createPromotion = '/create-promotion';
  static const home = '/home';
}
