class StaticAssets {
  static const String logo = 'assets/logo/app_logo.png';
  static const String logoLeaf = 'assets/logo/leaf_logo.png';

  //
  static const String phone = 'assets/utils/phone.png';
  static const String promotion = 'assets/utils/promotion.png';
}
