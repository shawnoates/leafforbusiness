part of 'cubit.dart';

class _CitiesRepository {}
