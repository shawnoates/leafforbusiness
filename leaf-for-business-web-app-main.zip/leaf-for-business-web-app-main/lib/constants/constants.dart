class Constants {
  static const String instagram = "https://instagram.com/togetherwithleaf";
  static const String facebook = "https://facebook.com/joinleaf";
  static const String contactEmail = "mailto:partners@getleaflets.co";
}
