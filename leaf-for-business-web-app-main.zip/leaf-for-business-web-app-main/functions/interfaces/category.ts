export interface ICategory {
    alias: string;
    title: string;
}