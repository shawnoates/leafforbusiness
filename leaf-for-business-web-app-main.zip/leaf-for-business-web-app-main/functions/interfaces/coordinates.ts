export interface ICoordinates {
    latitude: number;
    longitude: number;
}